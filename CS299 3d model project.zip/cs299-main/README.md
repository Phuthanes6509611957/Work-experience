# cs299
Added from 28/11/2023
- use raytracing for clicking on switch
- add audio when light on and off
- use meshphysicalmaterial for more realistic transparent object
- reorder code
- change pumpkin material to mesh physical material
- update tween animation 
- change skymap brightness
- add positional audio 
- change tween of ghost's speed to be constant
